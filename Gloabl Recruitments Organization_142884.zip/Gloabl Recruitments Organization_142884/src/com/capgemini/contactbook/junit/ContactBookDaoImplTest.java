package com.capgemini.contactbook.junit;

import junit.framework.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImplTest {

	static EnquiryBean enBean = null;
	static ContactBookDao conBookDao = null;
	
	@BeforeClass
	public static void beforeClass() throws ContactBookException
	{
		enBean = new EnquiryBean();
		conBookDao = new ContactBookDaoImpl();
	}
	
	@Test
	public void testAddEnquiry() throws ContactBookException
	{
		Assert.assertEquals(1, conBookDao.addEnquiry(enBean));
	}
	
	@Test
	public void testAddEnquiryIsNotNull() throws ContactBookException
	{
		Assert.assertNotNull(conBookDao.addEnquiry(enBean));
	}
	
	@Test
	public void testGetEnquiryDetails() throws ContactBookException
	{
		int enquiryId = enBean.getEnquiryId();
		Assert.assertNotNull(conBookDao.getEnquiryDetails(enquiryId));
	}
}
