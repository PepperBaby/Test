package com.capgemini.contactbook.ui;

import java.util.Scanner;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {
	static Scanner sc = null;
	static ContactBookService conBookSer = null;
	
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		conBookSer = new ContactBookServiceImpl();
		
		int choice = 0;
		while(true)
		{
			System.out.println("\n***************Global Recruitments******************");
			System.out.println("Choose an operation ");
			System.out.println("1. Enter Enquiry Details");
			System.out.println("2. View Enquiry Details on Id");
			System.out.println("0. Exit");
			System.out.println("****************************************************");

			System.out.println("Please enter a choice: ");
			
			choice = sc.nextInt();
			switch(choice)
			{
			case 1: enterEnquiryDetails();
			break;
			case 2: viewEnquiryDetailsOnId();
			break;
			default:
				System.out.println("Thank you for selecting us!!");
				System.exit(0);
			}
		}
	}
	
	/* *************************Main Ends Here************************* */
	
	//static methods used in main
	public static void enterEnquiryDetails()
	{
		System.out.println("Enter First Name : ");
		String fName=sc.next();
		System.out.println("Enter Last Name : ");
		String lName=sc.next();
		System.out.println("Enter Contact Number : ");
		String contactNo=sc.next();
		System.out.println("Enter Preferred Domain : ");
		String preDomain=sc.next();
		System.out.println("Enter Preferred Location : ");
		String preLocation=sc.next();
		
		EnquiryBean enBean = new EnquiryBean();
		enBean.setContactNo(contactNo);
		enBean.setfName(fName);
		enBean.setlName(lName);
		enBean.setpDomain(preDomain);
		enBean.setpLocation(preLocation);
		try
		{
			if(conBookSer.isValidEnquiry(enBean))
			{
			int dataAdded = conBookSer.addEnquiry(enBean);
			if(dataAdded==1)
			{
				System.out.println("Thank you "+enBean.getfName()+" "
			+enBean.getlName()+" your Unique Id is "+enBean.getEnquiryId()
			+" we will contact you shortly.");
			}
			else 
			{
				System.out.println("May raise some exception while entering details.");
			}
			}
		}
		catch (ContactBookException cbe) 
		{
			System.out.println(cbe.getMessage());
		}
	}
	
	public static void viewEnquiryDetailsOnId()
	{
		System.out.println("Enter the Enquiry No. : ");
		int enquiryNo = sc.nextInt();
		try
		{
			EnquiryBean enBean = conBookSer.getEnquiryDetails(enquiryNo);
			System.out.println("Id\t First Name\t Last Name\t Contact No.\t Preferred Domain\t Preferred Location");
			System.out.println(enBean.getEnquiryId()+"\t "+enBean.getfName()+"\t "+enBean.getlName()+"\t\t "+enBean.getContactNo()+"\t "+enBean.getpDomain()+"\t\t\t "+enBean.getpLocation());
		}
		catch (ContactBookException cbe) 
		{
			System.out.println("Sorry no details found!!");
		}
	}
}
