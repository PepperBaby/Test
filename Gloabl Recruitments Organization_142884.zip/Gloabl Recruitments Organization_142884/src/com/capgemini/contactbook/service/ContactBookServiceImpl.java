package com.capgemini.contactbook.service;

import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{

	ContactBookDao conBookDao = null;
	
	//Constructor
	public ContactBookServiceImpl() 
	{
		super();
		conBookDao = new  ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		return conBookDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enquiryId)
			throws ContactBookException {
		return conBookDao.getEnquiryDetails(enquiryId);
	}

	@Override
	public int generateEnquiryId() throws ContactBookException {
		return conBookDao.generateEnquiryId();
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		if( validateFirstName(enqry.getfName()) && validateLastName(enqry.getlName()) 
				&&  validateContactNo(enqry.getContactNo()) && validatePDomain(enqry.getpDomain())
				&& validatePLocation(enqry.getpLocation()))
		{	
		return true;
		}
		else
		{
			throw new ContactBookException("Invalid Input.");
		}
	}
	
	public boolean validateContactNo(String contactNo) throws ContactBookException
	{
		String numPattern = "[0-9]{10}";
		if(Pattern.matches(numPattern, contactNo))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only 10 digits allowed in Client Contact number.");
		}
	}
	
	public boolean validateFirstName(String fName) throws ContactBookException
	{
		String numPattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(numPattern, fName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("First Name should not be empty, only Characters allowed and "
					+ "starts with Capital letter e.g Babitha.");
		}
	}
	
	public boolean validateLastName(String lName) throws ContactBookException
	{
		String numPattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(numPattern, lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Last Name should not be empty, only Characters allowed and "
					+ "starts with Capital letter e.g Nadar.");
		}
	}
	
	public boolean validatePLocation(String pLocation) throws ContactBookException
	{
		String numPattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(numPattern, pLocation))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Preferred Location should not be empty, only Characters allowed and "
					+ "starts with Capital letter e.g Mumbai.");
		}
	}
	
	public boolean validatePDomain(String pDomain) throws ContactBookException
	{
		String numPattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(numPattern, pDomain))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Preferred Domain should not be empty, only Characters allowed and "
					+ "starts with Capital letter e.g Developer.");
		}
	}
}
