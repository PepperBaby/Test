package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBUtil;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao{

	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Logger enquiryLogger = null;
	
	//Constructor
	public ContactBookDaoImpl() {
		super();
		PropertyConfigurator.configure("resources/log4j.properties");
		enquiryLogger=Logger.getLogger("ContactBookDaoImpl.class");
		enquiryLogger.info("This is Enquiry Logger Details.");
	}
	
	//Java method to enter details into SQL enquiry table
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		String insertQry = "INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city) VALUES(?,?,?,?,?,?)";
		int dataAdded;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			int enquiryId =  generateEnquiryId();
			enqry.setEnquiryId(enquiryId);
			
			pst.setInt(1, enquiryId);
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setString(4, enqry.getContactNo());
			pst.setString(5, enqry.getpDomain());
			pst.setString(6, enqry.getpLocation());
			dataAdded =pst.executeUpdate();
			enquiryLogger.log(Level.INFO, "Client Enquiry Details Added : "+enqry);
		} 
		catch (Exception e) 
		{
			enquiryLogger.error("This is an exception: "+e.getMessage());
			throw new ContactBookException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return dataAdded;
	}

	//Java method to get details from SQL enquiry table based on enquiry Id
	@Override
	public EnquiryBean getEnquiryDetails(int enquiryId)
			throws ContactBookException {
		String selectQry = "SELECT * FROM enquiry WHERE enqryId=?";
		EnquiryBean en = null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setInt(1,enquiryId);
			rs = pst.executeQuery();
			rs.next();
			
			en = new EnquiryBean(rs.getInt("enqryId"),
				rs.getString("firstName"),rs.getString("lastName"),rs.getString("contactNo"),
				rs.getString("domain"),rs.getString("city"));
			enquiryLogger.log(Level.INFO, "Viewed Enquiry details on Id : "+enquiryId);	
		} 
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return en;
	}

	//Java method to generate enquiry Id for Client by sequence in SQL
	@Override
	public int generateEnquiryId() throws ContactBookException {
		String qry = "SELECT enquiries.NEXTVAL FROM DUAL";
		int generatedEquiryId;
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(qry);
			rs.next();
			generatedEquiryId = rs.getInt(1);
		} 
		catch (Exception e)
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return generatedEquiryId;
	}
}
