package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception 
{
	//User Defined exception
	public ContactBookException(String msg){
		super(msg);
}
}
