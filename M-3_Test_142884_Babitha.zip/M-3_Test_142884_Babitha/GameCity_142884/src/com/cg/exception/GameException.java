package com.cg.exception;

public class GameException extends Exception {

	public GameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	

	
}
