package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.GameException;
import com.cg.service.GameCityService;
import com.cg.service.GameCityServiceImpl;

//Servlet implementation class ProcessUser
@WebServlet(urlPatterns={"/showGames","/play"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	// @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	//@see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		String targetUrl = "";
		GameCityService gameSer = new GameCityServiceImpl();
		switch(url)
		{
		/*
		 * showGames case: takes user input from GameCity.jsp and inserts in Users Table.
		 * Later it selects all details from OnlineGames and forwards it to Play.jsp.
		 * If error exits it forwards the error message to Error.jsp.
		 */
		case "/showGames":
		{
			Users user = new Users();
			user.setUserName(request.getParameter("txtName"));
			user.setUserAddress(request.getParameter("address"));
			double enteredAmt = Double.parseDouble(request.getParameter("num"))-100;
			user.setCardAmt(enteredAmt);
			
			try 
			{
				gameSer.setUserDetails(user);
				
				HttpSession sess = request.getSession(true);
				sess.setAttribute("user", user);
				List<Games> gList = gameSer.getAllGames();
				sess.setAttribute("gList", gList);
				
				targetUrl = "Play.jsp";
			} 
			catch (GameException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		}
			break;
			
		/*
		 * play case: takes gameName and gameAmt from Play.jsp by session tracking 
		 * and sends to either Success.jsp which uses both parameters or
		 * Topup.jsp which uses gameName only
		 */
		case "/play":
			
			HttpSession sess = request.getSession(false);
			Users user = (Users) sess.getAttribute("user");
			
			double gameAmt = Double.parseDouble(request.getParameter("gameAmt"));
			String gameName = request.getParameter("gameName");
			sess.setAttribute("gamename", gameName);
			
			double userAmt = user.getCardAmt();
			
			if(userAmt>gameAmt)
			{
				double cardAmt = userAmt-gameAmt;
				sess.setAttribute("useramt", cardAmt);
				
				targetUrl = "Success.jsp";
			}
			else
			{
				targetUrl = "Topup.jsp";
			}
			break;
		}
		
		RequestDispatcher disp = request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}

}
