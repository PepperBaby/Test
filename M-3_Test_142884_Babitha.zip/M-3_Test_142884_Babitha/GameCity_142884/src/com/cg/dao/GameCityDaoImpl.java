package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.GameException;
import com.cg.util.DBUtil;

public class GameCityDaoImpl implements GameCityDao {
	Connection conn;
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.dao.GameCityDao#getAllGames()
	 * selects all game details from onlinegames table and returns list of details
	 */
	@Override
	public List<Games> getAllGames() throws GameException {
		
		conn = DBUtil.getConnection();
		List<Games> gList = new ArrayList<>();
		
		try 
		{
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECT_ONLINE_GAMES);
			while(rst.next())
			{
				Games game = new Games();
				game.setGameName(rst.getString("name"));
				game.setGameAmt(rst.getDouble("amount"));
				gList.add(game);
			}
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in fetching Game list: "+e.getMessage());
		}
		return gList;
	}
	
	//Private method of Dao that generates User Id automatically by using sequence
	private long generateUserId() throws GameException
	{
		long userId = 0 ;
		conn = DBUtil.getConnection();
		try 
		{
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			userId = rst.getLong(1);
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in generating User Id: " + e.getMessage());
		}
		
		return userId;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.dao.GameCityDao#setUserDetails(com.cg.dto.Users)
	 * inserts user details in users table from Users bean class
	 */
	@Override
	public long setUserDetails(Users user) throws GameException {
		user.setUserId(generateUserId());
		conn = DBUtil.getConnection();
		try 
		{
			PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERT_USER_INFO);
			pst.setLong(1, user.getUserId());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getUserAddress());			
			pst.setDouble(4, user.getCardAmt());
			
			pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in inserting User details: "+e.getMessage());
		}
		return user.getUserId();
	}

}
