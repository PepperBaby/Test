package com.cg.dao;

public interface QueryMapper {

	/*
	 * Contains all SQL queries used in Dao Layer
	 */
	String INSERT_USER_INFO = "INSERT INTO users(user_id,user_name,address,card_amt) VALUES(?, ?, ?, ?)";
	String SELECT_ONLINE_GAMES = "SELECT * FROM onlinegames";
	String SELECT_SEQUENCE = "Select seq_users.NEXTVAL FROM DUAL";
}
