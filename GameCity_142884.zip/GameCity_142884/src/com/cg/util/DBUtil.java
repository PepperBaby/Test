package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.GameException;

public class DBUtil {

	private static Connection conn;
	public static Connection getConnection() throws GameException{
		if(conn==null)
		{
			InitialContext ic;
			try 
			{
				ic = new InitialContext();
				DataSource ds =(DataSource) ic.lookup("java:/jdbc/OracleDS");
				conn = ds.getConnection();
			} 
			catch (NamingException e) 
			{
				throw new GameException("Problem in Obtaining Datasource: "+e.getMessage());	
			}
			catch (SQLException e) 
			{
				throw new GameException("Problem in Obtaining connection from Datasource: "+e.getMessage());
			}
		}
		return conn;
	}
}
