package com.cg.service;

import java.util.List;

import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.GameException;

public interface GameCityService {
	List<Games> getAllGames() throws GameException;
	long setUserDetails(Users user) throws GameException;
}
