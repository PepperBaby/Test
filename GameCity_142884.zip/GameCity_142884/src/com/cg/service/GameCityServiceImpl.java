package com.cg.service;

import java.util.List;

import com.cg.dao.GameCityDao;
import com.cg.dao.GameCityDaoImpl;
import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.GameException;

public class GameCityServiceImpl implements GameCityService {

	/*
	 * Communication between Dao layer and controller done by Service layer
	 */
	GameCityDao gameDao = new GameCityDaoImpl();
	@Override
	public List<Games> getAllGames() throws GameException {
		
		return gameDao.getAllGames();
	}

	@Override
	public long setUserDetails(Users user) throws GameException {
		
		return gameDao.setUserDetails(user);
	}

}
