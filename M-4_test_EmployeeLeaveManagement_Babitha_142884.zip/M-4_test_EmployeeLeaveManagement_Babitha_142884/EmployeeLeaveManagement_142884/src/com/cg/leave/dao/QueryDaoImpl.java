package com.cg.leave.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.leave.dto.EmployeeDetails;
import com.cg.leave.dto.EmployeeLeaveDetails;
/*
 * Provides the business Logic for the Application
 */
@Repository("employeedao")
public class QueryDaoImpl implements IQueryDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	/*
	 * Provides List of Employee Leave Details for given empId
	 */
	@Override
	public List<EmployeeLeaveDetails> getEmployeeDetails(long empId) {
		String q1="SELECT empLeaveDetails FROM EmployeeLeaveDetails empLeaveDetails WHERE empLeaveDetails.empId=:eId";
		TypedQuery<EmployeeLeaveDetails> query1=entitymanager.createQuery(q1,EmployeeLeaveDetails.class);
		query1.setParameter("eId", empId);
		return query1.getResultList();
	}

	/*Provides List of employee Ids existing in the EmployeeDetails table
	 */
			
	@Override
	public List<Long> getAllEmployeeIds() {
		String q1="SELECT empDetails.empId FROM EmployeeDetails empDetails";
		Query query1=entitymanager.createQuery(q1);
		return query1.getResultList();
	}

	/*
	 * Provides Employee Details for given empId
	 */
	@Override
	public EmployeeDetails getEmpDetail(long empId) {
		String q1="SELECT empDetails FROM EmployeeDetails empDetails WHERE empDetails.empId=:eId";
		TypedQuery<EmployeeDetails> query1=entitymanager.createQuery(q1,EmployeeDetails.class);
		query1.setParameter("eId", empId);
		EmployeeDetails empDet = query1.getSingleResult();
		return empDet;
	}

	/*
	 * Provides List of employee Ids existing in the EmployeeLeaveDetails table
	 */
	@Override
	public List<Long> getEmpIdsFromLeave() {
		String q1="SELECT empLeaveDetails.empId FROM EmployeeLeaveDetails empLeaveDetails";
		Query query1=entitymanager.createQuery(q1);
		return query1.getResultList();
	}

}
