package com.cg.leave.dao;

import java.util.List;

import com.cg.leave.dto.EmployeeDetails;
import com.cg.leave.dto.EmployeeLeaveDetails;
/*
 * Interface keeps declared methods secure
 */

public interface IQueryDao {

	public List<EmployeeLeaveDetails> getEmployeeDetails(long empId);
	public List<Long> getAllEmployeeIds();
	public EmployeeDetails getEmpDetail(long empId);
	public List<Long> getEmpIdsFromLeave();
}
