package com.cg.leave.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 * Contains employee details does not contain business logic
 */
@Entity
@Table(name="employee_details")
public class EmployeeDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	//variable declarations
	@Id
	@Column(name="empid")
	private long empId;
	
	@Column(name="ename")
	private String empName;
	
	@Column(name="address")
	private String address;
	
	@Column(name="leaves_avail")
	private Integer leavesAvail;
	
	//Getters and Setters
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getLeavesAvail() {
		return leavesAvail;
	}
	public void setLeavesAvail(Integer leavesAvail) {
		this.leavesAvail = leavesAvail;
	}
	
	
}
