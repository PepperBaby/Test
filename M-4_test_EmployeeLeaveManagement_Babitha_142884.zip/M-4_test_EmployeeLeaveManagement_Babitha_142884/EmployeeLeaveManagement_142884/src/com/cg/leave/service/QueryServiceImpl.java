package com.cg.leave.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.leave.dao.IQueryDao;
import com.cg.leave.dto.EmployeeDetails;
import com.cg.leave.dto.EmployeeLeaveDetails;
/*
 * Communicates between the DAO and the Controller
 */
@Service("employeeservice")
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDao employeedao;
	
	/*
	 * Forwards Employee Leave Details to the Controller
	 */
	@Override
	public List<EmployeeLeaveDetails> getEmployeeDetails(long empId) {
		
		return employeedao.getEmployeeDetails(empId);
	}

	/*
	 * Used to validate entered empId exists in the database table
	 */
	@Override
	public boolean validateEmpId(long empId) {
		List<Long> getIds=employeedao.getAllEmployeeIds();
		for(long i:getIds)
		{
			if(empId==i)
				return true;
		}
		return false;
	}

	/*
	 * Forwards Employee Details to the Controller
	 */
	@Override
	public EmployeeDetails getEmpDetail(long empId) {
		
		return employeedao.getEmpDetail(empId);
	}

	/*
	 * Used to validate entered empId exists in the database table
	 */
	@Override
	public boolean validateLeaveEmpId(long empId) {
		List<Long> getIds=employeedao.getEmpIdsFromLeave();
		for(long i:getIds)
		{
			if(empId==i)
				return true;
		}
		return false;
	}
}
