package com.cg.leave.service;

import java.util.List;

import com.cg.leave.dto.EmployeeDetails;
import com.cg.leave.dto.EmployeeLeaveDetails;
/*
 * Interface keeps declared methods secure
 */
public interface IQueryService {

	public List<EmployeeLeaveDetails> getEmployeeDetails(long empId);
	public boolean validateEmpId(long empId);
	public EmployeeDetails getEmpDetail(long empId);
	public boolean validateLeaveEmpId(long empId);
}
