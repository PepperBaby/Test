package com.cg.leave.ctrl;
/*
 * Name: Babitha Nadar
 * Project: EmployeeLeaveManagement_142884
 * Date: 23/2/2018
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.leave.dto.EmployeeDetails;
import com.cg.leave.dto.EmployeeLeaveDetails;
import com.cg.leave.service.IQueryService;
/*
 * controls client request and provides corresponding response
 */
@Controller
public class QueryController {

	@Autowired
	IQueryService employeeservice;

	@RequestMapping(value="home", method=RequestMethod.GET)
	public ModelAndView search(@ModelAttribute("my")EmployeeLeaveDetails empLeaveDetails,
			@RequestParam("eId")long empId)
	{
		ModelAndView mv = new ModelAndView();
		//Initially checks if Id exists in the employee_details table 
		if(employeeservice.validateEmpId(empId))
		{
			//Checks if Id exists in the employee_leave_details table
			if(employeeservice.validateLeaveEmpId(empId))
			{
				try
				{
					//fetches data from database and sends to  ViewLeaveDetails.jsp
					List<EmployeeLeaveDetails> leaveData=employeeservice.getEmployeeDetails(empId);
					EmployeeDetails empDetail = employeeservice.getEmpDetail(empId);

					mv.addObject("lData", leaveData);
					mv.addObject("empData", empDetail);
					mv.setViewName("ViewLeaveDetails");
					return mv;
				}
				catch (Exception e) 
				{
					//displays error in othererror.jsp page
					mv.addObject("message", e.getMessage());
					mv.setViewName("othererror");
					return mv;
				}
			}
			else
			{
				/*
				 * If data does not exists in employee_leave_details table 
				 * then displays ViewLeaveDetailsError.jsp page
				 */
				EmployeeDetails empDetail = employeeservice.getEmpDetail(empId);
				mv.addObject("empData", empDetail);
				mv.setViewName("ViewLeaveDetailsError");
				return mv;
			}
		}
		/*
		 * If data does not exists in employee_details table 
		 * then displays error.jsp page
		 */
		mv.addObject("temp", "This Employee ID Does not exist..");
		mv.setViewName("error");
		return mv;
	}
}
